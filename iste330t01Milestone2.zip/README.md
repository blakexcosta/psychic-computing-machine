* Run the SQL Script called Project_Tracker_Script.sql which is located in the SQLFiles folder.
* Run the mainTest.java class to see the fetches made to the user, project, email and office tables.
* If an error occurs in the mainTest.java file, make sure the connection values are correct and that you've added the proper class paths for the project.