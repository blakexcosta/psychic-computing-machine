package View;

/**
 * Blake Costa, Gavin Drabik, Matthew Turczmanovicz, Oswaldo Rosete-Garcia, and Quinn Bissen
 * Group 11
 * ISTE-330
 * Professor Floeser
 * November 10th, 2017
 */
public class LoginView extends View{

    /**
     * Purpose: Constructor
     * @param
     * @return
     */
    public LoginView() {
        super();
    }
}
